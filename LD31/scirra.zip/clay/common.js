﻿/*
 * Nothing in common :(
 */